if event.key == pygame.K_e:
                player.pickup()